package com.oneplus.fp.emoji.anim

import android.graphics.drawable.AnimationDrawable
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

class MainActivity : AppCompatActivity() {

    private lateinit var animView: ImageView
    private lateinit var statusText: TextView
    private var frameAnimation: AnimationDrawable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // Required for clean Android 15 (API 35) Edge-to-Edge enforcement
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root_container)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(left = bars.left, top = bars.top, right = bars.right, bottom = bars.bottom)
            insets
        }

        animView = findViewById(R.id.fod_animation_view)
        statusText = findViewById(R.id.status_label)
        val btnBiometric = findViewById<Button>(R.id.btn_test_biometric)
        val btnReplay = findViewById<Button>(R.id.btn_replay_anim)
        val specText = findViewById<TextView>(R.id.device_spec_label)

        specText.text = "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · Target ${getString(R.string.target_pkg)}"

        animView.setImageResource(R.drawable.fp_anim_emoji)
        frameAnimation = animView.drawable as? AnimationDrawable

        animView.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    startFpAnimation()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    stopFpAnimation()
                    true
                }
                else -> false
            }
        }

        btnReplay.setOnClickListener {
            startFpAnimation()
        }

        btnBiometric.setOnClickListener {
            launchAndroid15BiometricPrompt()
        }

        // Play initial preview cycle
        animView.post { startFpAnimation() }
    }

    private fun startFpAnimation() {
        frameAnimation?.stop()
        frameAnimation?.start()
        statusText.text = "Scanning optical fingerprint sensor..."
    }

    private fun stopFpAnimation() {
        statusText.text = "Hold emoji sensor to preview animation"
    }

    private fun launchAndroid15BiometricPrompt() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "No hardware fingerprint enrolled on this device", Toast.LENGTH_SHORT).show()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    startFpAnimation()
                    statusText.text = "Biometric verified on Android ${Build.VERSION.RELEASE}"
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    statusText.text = "Prompt cancelled: $errString"
                }
            }
        )

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("OnePlus Emoji FOD Test")
            .setSubtitle("Verify under-display fingerprint compatibility on Android 15")
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(authenticators)
            .build()

        prompt.authenticate(info)
    }
}
